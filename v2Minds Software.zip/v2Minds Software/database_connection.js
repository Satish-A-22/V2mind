const express = require("express");
const bodyParser = require("body-parser");
const mariadb = require("mariadb");
const path = require("path");    
const nodemailer = require("nodemailer");
const app = express();
const port = 3000;

app.set("view engine", "ejs");

app.set("views", path.join(__dirname, "views"));


app.use(bodyParser.urlencoded({ extended: true }));

const pool = mariadb.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "Sath@1234",
  database: "student_notes",
  connectionLimit: 5,
});

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "satisharumugam2001@gmail.com",
    pass: "tixp fkvv ioyd snvp", 
  },
});

app.post("/forgot-password", async (req, res) => {
  const email = req.body.email;
  console.log(email);
  if (!email) return res.status(400).send("Email is required");

  let conn;
  try {
    conn = await pool.getConnection();

    const result = await conn.query(
      "SELECT password FROM student WHERE email = ?",
      [email]
    );
    // console.log(result[0]);
    if (result.length > 0) {
      const password = result[0].password;

      
      const mailOptions = {
        from: "satisharumugam2001@gmail.com",
        to: email,
        subject: "Your Password",
        text: `Your password is: ${password}`,
      };

      await transporter.sendMail(mailOptions);
      res.send("Password has been sent to your email");
    } else {
      res.send("Email not found in our records. Please create a new account.");
    }
  } catch (err) {
    console.error("Error:", err);
    res.status(500).send("Error checking email or sending password.");
  } finally {
    if (conn) conn.end();
  }
});

app.post("/home", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).send("All fields are required!");

  let conn;
  try {
    conn = await pool.getConnection();
    console.log("Connected to MariaDB!");

    const user = await conn.query("SELECT * FROM student WHERE Email = ?", [
      email,
    ]);

    if (user.length > 0) {
      return res.send(
        "Email already exists. Please try logging in or use another email."
      );
    }

    
    await conn.query(
      "INSERT INTO student (Name, Email, Password) VALUES (?, ?, ?)",
      [name, email, password]
    );
    console.log("Inserted a new student!");

    res.redirect("/note");
  } catch (err) {
    console.error("Error:", err);
    res.status(500).send("Error saving student data.");
  } finally {
    if (conn) conn.end();
  }
});

app.post("/note", async (req, res) => {
  const { title, description } = req.body;
  if (!title || !description)
    return res.status(400).send("All fields are required!");

  let conn;
  try {
    conn = await pool.getConnection();
    console.log("Connected to MariaDB!");


    await conn.query(
      "INSERT INTO notes (title, description, time) VALUES (?, ?, current_timestamp())",
      [title, description]
    );
    console.log("Inserted a new note!");

    res.redirect("/notes");
  } catch (err) {
    console.error("Error:", err);
    res.status(500).send("Error saving note.");
  } finally {
    if (conn) conn.end();
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).send("Email and password are required!");

  let conn;
  try {
    conn = await pool.getConnection();
    console.log("Connected to MariaDB!");

    // Check if the email and password match a record in the database
    const user = await conn.query(
      "SELECT * FROM student WHERE Email = ? AND Password = ?",
      [email, password]
    );

    if (user.length > 0) {
      return res.redirect("/note");
    } else {
      return res.send("Incorrect email or password. Please try again.");
    }
  } catch (err) {
    console.error("Error during login:", err);
    res.status(500).send("Error during login.");
  } finally {
    if (conn) conn.end();
  }
});

app.get("/notes", async (req, res) => {
  let conn;
  try {
    conn = await pool.getConnection();
    const rows = await conn.query("SELECT * FROM notes");

    res.render("notes-list", { notes: rows });
  } catch (err) {
    console.error("Error fetching notes:", err);
    res.status(500).send("Error fetching notes");
  } finally {
    if (conn) conn.end();
  }
});

// Route to delete a note
app.post("/delete-note/:id", async (req, res) => {
  const noteId = req.params.id;

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.query("DELETE FROM notes WHERE id = ?", [noteId]);
    res.redirect("/notes");
  } catch (err) {
    console.error("Error deleting note:", err);
    res.status(500).send("Error deleting note");
  } finally {
    if (conn) conn.end();
  }
});


app.get("/update-note/:id", async (req, res) => {
  const noteId = req.params.id;

  let conn;
  try {
    conn = await pool.getConnection();
    const note = await conn.query("SELECT * FROM notes WHERE id = ?", [noteId]);
    res.render("update-note", { note: note[0] });
  } catch (err) {
    console.error("Error fetching note for update:", err);
    res.status(500).send("Error fetching note");
  } finally {
    if (conn) conn.end();
  }
});


app.post("/update-note/:id", async (req, res) => {
  const noteId = req.params.id;
  const { title, description } = req.body;

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.query(
      "UPDATE notes SET title = ?, description = ? WHERE id = ?",
      [title, description, noteId]
    );
    res.redirect("/notes");
  } catch (err) {
    console.error("Error updating note:", err);
    res.status(500).send("Error updating note");
  } finally {
    if (conn) conn.end();
  }
});

app.get("/", (req, res) => res.sendFile(path.join(__dirname, "login.html")));
app.get("/home", (req, res) => res.sendFile(path.join(__dirname, "home.html")));
app.get("/note", (req, res) => res.sendFile(path.join(__dirname, "note.html")));
app.get("/forgot", (req, res) =>
  res.sendFile(path.join(__dirname, "forgot.html"))
);

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
